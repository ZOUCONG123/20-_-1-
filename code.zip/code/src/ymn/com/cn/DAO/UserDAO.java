package ymn.com.cn.DAO;


import ymn.com.cn.Until.DBUtil;

public class UserDAO {
	private DBUtil dbUtil;
	public boolean findUser(String userName,String userPassword) {
		return false;
		
	}
}
