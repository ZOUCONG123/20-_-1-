package ymn.com.cn.main;

public class LoginForm {
	
		public void init() {
			
		}
		public void display() {
			
		}
		public void validate() {
			
		}
}
