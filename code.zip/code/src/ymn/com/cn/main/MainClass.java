package ymn.com.cn.main;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class MainClass extends JFrame {
	public static void main(String[] args) {
		new MainClass();
	}
	private static final long serialVersionUID = 1L;
	private JButton jbtn;
	private JLabel jl1,jl2;
	private JTextField jtf1;
	private JPasswordField jpw2;
	public MainClass() {
		this.setLocation(400,300);
		this.setSize(300,120);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setTitle("�û���¼");
		this.setLayout(new FlowLayout());
		
		jl1 = new JLabel("�� ��:");
		jl2 = new JLabel("�� ��:");
		jbtn = new JButton("��¼");
		
		//�����ಿ�࣬ʵ�ְ�ť����
		jbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Input();
			}
		});
		jtf1 = new JTextField(20);
		jpw2 = new JPasswordField(20);
		this.add(jl1);this.add(jtf1);this.add(jl2);this.add(jpw2);this.add(jbtn);
		this.setVisible(true);
	}
	
	public void Input() {
		
	}
}
